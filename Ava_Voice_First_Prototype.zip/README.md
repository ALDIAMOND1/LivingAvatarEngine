# Living Avatar Engine — Ava Character 01

## Open Ava now
Run `OPEN_AVA.cmd` in this folder, or start `python -m http.server 8765 --bind 127.0.0.1` and open **http://127.0.0.1:8765/**.

Click **Start talking** once to authorize the browser microphone, then speak commands such as "look left", "look right", "look at me", "nod", "blink", or "introduce yourself". Ordinary basic greetings also receive a spoken response.

This is a LOCAL research prototype, not a production photorealistic digital-human engine. A true 3D reconstruction, expression rig, mouth shapes, full audio/viseme sync, general AI conversation, and user-consented asset pipeline are still unfinished.

## Implemented and verified
- Original synthetic Ava portrait in `characters/ava/assets/portrait/ava-master.webp`.
- Separate prepared photographic blink and gaze eye-state atlas in `characters/ava/assets/face/ava-eye-atlas.webp`.
- Portrait-based independently blended eyelid/eye poses and bounded idle scheduler.
- Small feathered face-region motion (2D approximation, **NOT** actual 3D head geometry).
- Voice-first interface; browser Web Speech speech recognition where available.
- Recognized gesture commands dispatched to motion controller without gesture buttons.
- Basic scripted conversational responses using browser speech synthesis.
- TTS word-boundary timing captured for future mouth integration; visual lip-sync is not implemented.
- Local server requires no commercial AI subscription or continuous GPU inference.

## Project structure
- `index.html` — current voice-first Ava application.
- `src/ava-app.js` — UI and state integration.
- `src/ava-renderer.js` — compact eye-state atlas + portrait compositor.
- `src/ava-motion.js` — idle/blink/gaze/nod and limited mouth scheduling.
- `src/ava-voice.js` — STT/TTS and command/dialogue handling.
- `src/ava.css` — responsive interface.
- `characters/ava/` — character profile, manifests, requirements, assets, intent parser and tests.
- `tests/browser_smoke.py`, `tests/capture_states.py`, `tests/ava-motion.test.mjs` — verification tooling.
- `PROJECT_MASTER_SPEC.md`, `VOICE_FIRST_REALISM_REQUIREMENTS.md` — product architecture and nonnegotiable quality criteria.
- `PROGRESS.md` — measured status and next blockers.
- `src/main.js` and `src/style.css` are unused remnants of the retired placeholder experiment.

## Test commands
From this project directory:
```powershell
node characters/ava/validate.mjs
node --test tests/ava-motion.test.mjs characters/ava/tests/intent-parser.test.mjs
python tests/browser_smoke.py
```
The browser test uses the installed Edge channel with Playwright and does **not** test a physical microphone.

## Privacy and limits
- All portrait and animation rendering happens in the browser locally.
- Browser SpeechRecognition may use vendor cloud services; it is not guaranteed to run offline.
- No general LLM/API credentials are connected or stored.
- No hidden voice recording is implemented; browser microphone access requires permission.
- Ava is an original fictional AI-generated face, not a replica of the Nuance Labs person.
- Avoid calling this a fully lifelike talking avatar until independently validated against real footage.

## Next milestone
1. Produce a higher-resolution, aligned neutral/eyelid/mouth asset pack and validate visual consistency.
2. Fit a real 2.5D or 3D expressive facial mesh. Compare identity stability versus cheap pose assets.
3. Switch speech output to audio buffers with real PCM and build an audio-to-viseme controller.
4. Add provider-agnostic general conversational AI (OpenAI Realtime is a candidate, requires authorized usage).
5. Test microphone audio, response latency, naturalness, long-running frame timings and memory on actual hardware.
