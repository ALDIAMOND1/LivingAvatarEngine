# Ava — Build Progress

Date: 2026-11-22

## What is actually built
- Original Ava photorealistic portrait generated (fictional person) and imported to connected Windows machine.
- Image SHA-256 transfer verified for portrait and prepared eye atlas.
- Blink, left/right gaze, subtle idle/face movement in a local HTML canvas renderer.
- Voice-command parser and microphone/speech synthesis integration via browser Web Speech.
- Responsive voice-first app. One microphone permission gesture; NO click-only gesture controls.
- Word-boundary timing is captured, but visual mouth movement is disabled: a crude image deformation failed visual QA.
- Compact eye asset atlas: 5,762 bytes in the local dev build. Neutral portrait: ~4.9 KB preview resolution. Source full-resolution portrait is available as a separate ChatGPT-generated artifact.

## Observed test results
- 14/14 Node motion and parser unit tests passing.
- Character validator: 0 errors; two required future 3D geometry/texture assets missing.
- Edge/Playwright: HTTP 200; renderer ready; atlas 288×513; SpeechRecognition constructor available; no page JavaScript errors in smoke test.
- Reported FPS in headless Edge smoke test varied around 35–50 FPS; this does NOT replace an interactive GPU/memory benchmark.

## Not completed / must not be claimed as completed
- Real reconstructed 3D head and proper parallax/occlusions.
- Full eyelid skin deformation across arbitrary head angles.
- Fully articulated cheek, jaw, teeth, tongue and viseme morphs.
- Real generated-audio PCM lip synchronization.
- Full conversational AI provider, barge-in and network resiliency.
- Live physical microphone speech tested by a person.
- 30-minute memory soak and visual realism blind comparison.

## Engineering decision
Our low-memory approach works as a **2D prepared-appearance + procedural motion** research baseline. We must compare it with 2.5D/3D options before claiming Nuance-level realism. Current facial head patch movement is deliberately tiny to avoid fake flat rotation.

## Known problems and next tasks
- Small preview assets are visibly softer than the full portrait; replace with larger optimized source/atlas once available.
- Left-looking gaze uses a mirrored prepared patch; correct with a dedicated approved pose.
- Browser's speech recognition may rely on an external service despite local visual rendering.
- SpeechSynthesis does not expose actual PCM output; word-boundary events are coarse and may not fire on all voices. We need actual prepared mouth poses and PCM-driven visemes.
- No browser-accessible TTS/ASR/LLM provider credentials should be hardcoded.
